import argparse
from utils import get_data,data_processing
from train import train
import os
import torch as th
import numpy as np
import pandas as pd
th.manual_seed(123)
device = th.device("cuda:0" if th.cuda.is_available() else "cpu")
def result(args):
    data = get_data(args)
    args.miRNA_number = data['miRNA_number']
    args.disease_number = data['disease_number']
    data_processing(data,args)
    train(data,args)
    # 此处添加了一部分
    # pd.DataFrame(score).to_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/C_result.csv")


os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'


parser = argparse.ArgumentParser()
parser.add_argument('--epochs', type=int, default=60, metavar='N', help='number of epochs to train') #本模型采用门控函数训练epoch为100，简单拼接epoch为250，注意力机制epoch为250  #C数据集为250，F数据集为150
parser.add_argument('--fm', type=int, default=64, help='length of miRNA feature')
parser.add_argument('--fd', type=int, default=64, help='length of dataset feature')
parser.add_argument('--wd', type=float, default=1e-3, help='weight_decay')
parser.add_argument('--lr', type=float, default=5e-4, help='learning rate')#最佳5e-4
parser.add_argument("--in_feats", type=int, default=64, help='Input layer dimensionalities.')
parser.add_argument("--hid_feats", type=int, default=64, help='Hidden layer dimensionalities.')
parser.add_argument("--out_feats", type=int, default=64, help='Output layer dimensionalities.')
parser.add_argument("--method", default='sum', help='Merge feature method')
parser.add_argument("--gat_bias", type=bool, default=True, help='gat bias')
parser.add_argument("--gat_batchnorm", type=bool, default=True, help='gat batchnorm')
parser.add_argument("--gat_activation", default='elu', help='gat activation')#elu
parser.add_argument("--num_layers", type=int, default=3, help='Number of GAT layers.')
parser.add_argument("--input_dropout", type=float, default=0, help='Dropout applied at input layer.')#0
parser.add_argument("--layer_dropout", type=float, default=0, help='Dropout applied at hidden layers.')#0
parser.add_argument('--random_seed', type=int, default=123, help='random seed')
parser.add_argument('--early_stopping', type=int, default=50, help='stop')#200
parser.add_argument('--dropout', type=float, default=0.2, help='dropout')#0.2
parser.add_argument('--mlp', type=list, default=[64, 1], help='mlp layers')#[64, 1]
parser.add_argument('--neighbor', type=int, default=15, help='neighbor') #20
parser.add_argument('--dataset', default='HMDD v2.0', help='dataset')
parser.add_argument('--save_score', default='True', help='save_score')
parser.add_argument('--negative_rate', type=float,default=1.0, help='negative_rate')

args = parser.parse_args()
args.dd2=False
args.data_dir = 'data/' + args.dataset + '/'
args.result_dir = 'result/' + args.dataset + '/'
args.save_score = True if str(args.save_score) == 'True' else False


result(args)
