import pandas as pd
import numpy as np
from sklearn.metrics import (
    roc_auc_score, average_precision_score, accuracy_score,
    f1_score, precision_score, recall_score, roc_curve
)

# ===================== 1. 定义路径和参数 =====================
base_path1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold/"
base_path = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold-high-and-att/"
n_folds = 10
metrics_results = {
    'fold': [],
    'best_threshold': [],
    'auc': [],
    'aupr': [],
    'accuracy': [],
    'f1': [],
    'precision': [],
    'recall': []
}


# ===================== 2. 兼容低版本sklearn的精确率计算函数 =====================
def safe_precision_score(y_true, y_pred):
    """
    兼容低版本sklearn的精确率计算，避免除以0错误
    """
    try:
        # 低版本sklearn无zero_division参数，直接计算
        return precision_score(y_true, y_pred)
    except ValueError:
        # 当预测全为负例时，返回0
        return 0.0


# ===================== 3. 循环读取每折数据并计算指标 =====================
for fold in range(n_folds):
    true_path = f"{base_path1}C_test_fold_{fold}.csv"
    score_path = f"{base_path}C_test_result_fold_{fold}.csv"

    try:
        # 读取数据
        y_true = np.array(pd.read_csv(true_path).iloc[:, 3])
        y_scores = np.array(pd.read_csv(score_path).iloc[:, 1])

        # 计算AUC和AUPR
        auc = roc_auc_score(y_true, y_scores)
        aupr = average_precision_score(y_true, y_scores)

        # 计算最优阈值（约登指数）
        fpr, tpr, thresholds = roc_curve(y_true, y_scores)
        j_scores = tpr - fpr
        best_idx = np.argmax(j_scores)
        best_threshold = thresholds[best_idx]

        # 基于最优阈值生成预测标签
        y_pred = (y_scores >= best_threshold).astype(int)

        # 计算分类指标（使用兼容版精确率函数）
        accuracy = accuracy_score(y_true, y_pred)
        f1 = f1_score(y_true, y_pred)
        precision = safe_precision_score(y_true, y_pred)  # 替换为兼容函数
        recall = recall_score(y_true, y_pred)

        # 存储结果
        metrics_results['fold'].append(fold)
        metrics_results['best_threshold'].append(best_threshold)
        metrics_results['auc'].append(auc)
        metrics_results['aupr'].append(aupr)
        metrics_results['accuracy'].append(accuracy)
        metrics_results['f1'].append(f1)
        metrics_results['precision'].append(precision)
        metrics_results['recall'].append(recall)

        # 打印当前折结果
        print(f"===== Fold {fold} 结果 =====")
        print(f"最优阈值: {best_threshold:.4f}")
        print(f"AUC: {auc:.4f} | AUPR: {aupr:.4f}")
        print(f"Accuracy: {accuracy:.4f} | F1: {f1:.4f}")
        print(f"Precision: {precision:.4f} | Recall: {recall:.4f}\n")

    except Exception as e:
        print(f"❌ 处理Fold {fold} 时出错：{str(e)}")
        # 出错时填充NaN（保证所有列长度一致）
        metrics_results['fold'].append(fold)
        metrics_results['best_threshold'].append(np.nan)
        metrics_results['auc'].append(np.nan)
        metrics_results['aupr'].append(np.nan)
        metrics_results['accuracy'].append(np.nan)
        metrics_results['f1'].append(np.nan)
        metrics_results['precision'].append(np.nan)
        metrics_results['recall'].append(np.nan)

# ===================== 4. 计算汇总结果（兼容空数据） =====================
metrics_df = pd.DataFrame(metrics_results)
# 只计算有效数据的均值和标准差
valid_df = metrics_df.dropna()

# 定义需要汇总的指标
metrics_list = ['best_threshold', 'auc', 'aupr', 'accuracy', 'f1', 'precision', 'recall']
summary_data = {'metric': [], 'mean': [], 'std': []}

for metric in metrics_list:
    if len(valid_df) > 0:
        mean_val = valid_df[metric].mean()
        std_val = valid_df[metric].std()
    else:
        mean_val = np.nan
        std_val = np.nan
    summary_data['metric'].append(metric)
    summary_data['mean'].append(mean_val)
    summary_data['std'].append(std_val)

# 打印汇总结果
print("=" * 50)
print("===== 10折交叉验证汇总结果（均值±标准差） =====")
for metric in metrics_list:
    mean_val = summary_data['mean'][summary_data['metric'].index(metric)]
    std_val = summary_data['std'][summary_data['metric'].index(metric)]
    if not np.isnan(mean_val):
        print(f"{metric}: {mean_val:.4f} ± {std_val:.4f}")
    else:
        print(f"{metric}: 无有效数据")

# ===================== 5. 保存结果 =====================
# 保存详细结果
detail_path = f"{base_path}10fold_metrics_detail.csv"
metrics_df.to_csv(detail_path, index=False, float_format='%.4f')

# 保存汇总结果
summary_df = pd.DataFrame(summary_data)
summary_path = f"{base_path}10fold_metrics_summary.csv"
summary_df.to_csv(summary_path, index=False, float_format='%.4f')

print("\n✅ 结果文件已保存：")
print(f"- 每折详细结果：{detail_path}")
print(f"- 汇总结果：{summary_path}")