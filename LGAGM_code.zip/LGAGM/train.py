from MAMFGAT import MAMFGAT
from torch import optim,nn
from tqdm import trange
from utils import k_matrix
import dgl
import networkx as nx
import copy
import numpy as np
import pandas as pd
import torch as th
from sklearn.metrics import roc_auc_score,precision_recall_curve,auc,accuracy_score, precision_score, recall_score, f1_score,roc_curve
from sklearn.model_selection import KFold
import torch.nn.functional as F
import scipy.sparse as sp
import matplotlib.pyplot as plt
th.manual_seed(123)
device = th.device("cuda:0" if th.cuda.is_available() else "cpu")
kfolds=10
def print_met(list):
    print('AUC ：%.4f ' % (list[0]),
          'AUPR ：%.4f ' % (list[1]),
          'Accuracy ：%.4f ' % (list[2]),
          'precision ：%.4f ' % (list[3]),
          'recall ：%.4f ' % (list[4]),
          'f1_score ：%.4f \n' % (list[5]))

# def loss_contrastive_m(m1,m2):
#     m1,m2= (m1/th.norm(m1)),(m2/th.norm(m2))
#     pos_m1_m2 = th.sum(m1 * m2, dim=1, keepdim=True)
#     neg_m1 = th.matmul(m1, m1.t())
#     neg_m2 = th.matmul(m2, m2.t())
#     neg_m1 = neg_m1 - th.diag_embed(th.diag(neg_m1))
#     neg_m2 = neg_m2 - th.diag_embed(th.diag(neg_m2))
#     pos_m = th.mean(th.cat([pos_m1_m2],dim=1),dim=1)
#     neg_m = th.mean(th.cat([neg_m1, neg_m2], dim=1), dim=1)
#     loss_m = th.mean(F.softplus(neg_m-pos_m))
#
#     return loss_m
#
# def loss_contrastive_d(d1,d2):
#     d1, d2 = d1/th.norm(d1), d2/th.norm(d2)
#     pos_d1_d2 = th.sum(d1 * d2, dim=1, keepdim=True)
#     neg_d1 = th.matmul(d1, d1.t())
#     neg_d2 = th.matmul(d2, d2.t())
#     neg_d1 = neg_d1 - th.diag_embed(th.diag(neg_d1))
#     neg_d2 = neg_d2 - th.diag_embed(th.diag(neg_d2))
#     pos_d = th.mean(th.cat([pos_d1_d2], dim=1), dim=1)
#     neg_d = th.mean(th.cat([neg_d1, neg_d2], dim=1), dim=1)
#     loss_d = th.mean(F.softplus(neg_d-pos_d ))
#
#     return loss_d

def loss_contrastive_m(m1,m2):
    m1,m2= (m1/th.norm(m1)),(m2/th.norm(m2))
    pos_m1_m2 = th.sum(m1 * m2, dim=1, keepdim=True)
    neg_m1 = th.matmul(m1, m1.t())
    neg_m2 = th.matmul(m2, m2.t())
    neg_m1 = neg_m1 - th.diag_embed(th.diag(neg_m1))
    neg_m2 = neg_m2 - th.diag_embed(th.diag(neg_m2))
    pos_m = th.mean(th.cat([pos_m1_m2],dim=1),dim=1)
    neg_m = th.mean(th.cat([neg_m1, neg_m2], dim=1), dim=1)
    loss_m = th.mean(F.softplus(pos_m-neg_m))

    return loss_m

def loss_contrastive_d(d1,d2):
    d1, d2 = d1/th.norm(d1), d2/th.norm(d2)
    pos_d1_d2 = th.sum(d1 * d2, dim=1, keepdim=True)
    neg_d1 = th.matmul(d1, d1.t())
    neg_d2 = th.matmul(d2, d2.t())
    neg_d1 = neg_d1 - th.diag_embed(th.diag(neg_d1))
    neg_d2 = neg_d2 - th.diag_embed(th.diag(neg_d2))
    pos_d = th.mean(th.cat([pos_d1_d2], dim=1), dim=1)
    neg_d = th.mean(th.cat([neg_d1, neg_d2], dim=1), dim=1)
    loss_d = th.mean(F.softplus(pos_d-neg_d))

    return loss_d



def train(data,args):
    all_score=[]

    # 设置随机种子
    random_seed = 42
    np.random.seed(random_seed)
    kf = KFold(n_splits=kfolds, shuffle=True, random_state=random_seed)
    # kf = KFold(n_splits=kfolds, shuffle=True, random_state=1)
    train_idx, valid_idx = [], []
    for train_index, valid_index in kf.split(data['train_samples']):
        train_idx.append(train_index)
        valid_idx.append(valid_index)
    for i in range(kfolds):
        # 此处为自己添加的部分
        fold = i

        one_score = []
        model = MAMFGAT(args).to(device)
        optimizer = optim.AdamW(model.parameters(), weight_decay=args.wd, lr=args.lr)
        cross_entropy = nn.BCELoss()

        miRNA = data['ms']
        disease = data['ds']


        # a, b = data['train_samples'][train_idx[i]], data['train_samples'][valid_idx[i]]

        # Bdataset
        # text_file = "D:/pyproject/Bioinfomatics_new/DRMAHGC-main/data/B-dataset/fold/{}/data_test.csv".format(fold)
        # text_file2 = "D:/pyproject/Bioinfomatics_new/DRMAHGC-main/data/B-dataset/fold/{}/data_train.csv".format(fold)

        text_file = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold/F_test_fold_{}.csv".format(fold)
        text_file2 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold/F_train_fold_{}.csv".format(fold)


        # text_file = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold/C_test_fold_{}.csv".format(fold)
        # text_file2 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold/C_train_fold_{}.csv".format(fold)

        # a=np.array(pd.read_csv(text_file2).iloc[:,1:])
        # b=np.array(pd.read_csv(text_file).iloc[:,1:])


        print(f'################Fold {i + 1} of {kfolds}################')
        epochs = trange(args.epochs, desc='train')
        for _ in epochs:
            model.train()
            optimizer.zero_grad()
            mm_matrix = k_matrix(data['ms'], args.neighbor)
            dd_matrix = k_matrix(data['ds'], args.neighbor)
            mm_nx=nx.from_numpy_matrix(mm_matrix)
            dd_nx=nx.from_numpy_matrix(dd_matrix)


            mm_graph = dgl.from_networkx(mm_nx)
            dd_graph = dgl.from_networkx(dd_nx)
            md_copy = copy.deepcopy(data['train_md'])
            md_copy[:, 1] = md_copy[:, 1] + args.miRNA_number
            md_graph = dgl.graph((np.concatenate((md_copy[:, 0], md_copy[:, 1])), np.concatenate((md_copy[:, 1], md_copy[:, 0]))),num_nodes=args.miRNA_number + args.disease_number)
            miRNA_th=th.Tensor(miRNA)
            disease_th=th.Tensor(disease)

            # train_samples_th = th.Tensor(a).float()
            # train_score,m1,m2,d1,d2 = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, a)
            train_samples_th = th.Tensor(data['train_samples'][train_idx[i]]).float()
            train_score, m1, m2, d1, d2 = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, data['train_samples'][train_idx[i]])

            train_m_loss = loss_contrastive_m(m1, m2)
            train_d_loss = loss_contrastive_d(d1, d2)

            train_cross_loss = cross_entropy(th.flatten(train_score), train_samples_th[:, 2].to(device))
            train_loss = train_cross_loss + train_d_loss + train_m_loss
            # scoree, _, _, _, _ = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, b)
            scoree, _, _, _, _ = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, data['train_samples'][train_idx[i]])
            scoree = scoree.cpu()
            scoree = scoree.detach().numpy()

            # sc = data['train_samples'][valid_idx[i]]
            sc = data['train_samples'][train_idx[i]]
            sc_true = sc[:, 2]
            aucc = roc_auc_score(sc_true, scoree)

            # save_text = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Bdataset/10-fold/B_train_fold_{}.csv".format(fold)
            # pd.DataFrame(sc).to_csv(save_text)




            print("AUC=",np.round(aucc,4),"l_1=",np.round(train_cross_loss.item(),4),"l_2=",np.round(train_m_loss.item(),4),"l_3=",np.round(train_d_loss.item(),4),"loss=",np.round(train_loss.item(),4))
            #print("AUC=", np.round(aucc, 4), "l_1=", np.round(train_cross_loss.item(), 4), "l_2=",np.round(train_m_loss.item(), 4), "l_3=", np.round(train_d_loss.item(), 4))
            train_loss.backward()
            #train_cross_loss.backward()
            optimizer.step()

        model.eval()


        # scoree,_,_,_,_ = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, b)
        scoree, _, _, _, _ = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, data['train_samples'][valid_idx[i]])
        scoree = scoree.cpu()
        scoree = scoree.detach().numpy()


        sc=data['train_samples'][valid_idx[i]]
        sc_true=sc[:,2]
        fpr, tpr, thresholds = roc_curve(sc_true, scoree)
        # save_text = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Bdataset/10-fold/B_test_fold_{}.csv".format(fold)
        # pd.DataFrame(sc).to_csv(save_text)

        # 选择最佳阈值
        optimal_idx = np.argmax(tpr - fpr)
        optimal_threshold = thresholds[optimal_idx]
        print("Best threshold：{:.4f}".format(optimal_threshold))

        # 计算auc
        aucc = roc_auc_score(sc_true, scoree)
        print("AUC: {:.6f}".format(aucc))

        # 计算aupr
        precision, recall, thresholds = precision_recall_curve(sc_true, scoree)
        auprc = auc(recall, precision)
        print("AUPRC: {:.6f}".format(auprc))

        # C数据集
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold/C_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # 消融实验
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold-high-and-att/C_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # LGAT vs GAT
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold-GAT/C_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold-attention/C_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold-concentrate/C_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)

        # F数据集，未归结到0、1
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold/F_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # 消融实验
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold-high-and-att/F_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # LGAT vs GAT
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold-GAT/F_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # Attention
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold-attention/F_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)
        # concentrate
        # text_file1 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold-concentrate/F_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file1)

        scoree=np.array(scoree)
        # scoree=np.around(scoree, 0).astype(int)
        scoree = scoree.ravel()


        for i in range(len(scoree)):
            if scoree[i] >=optimal_threshold:
                scoree[i]=1
            else:
                scoree[i]=0

        # C数据集
        # text_file3 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/10-fold-result/C_test_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file3)
        # F数据集，归结到0、1
        # text_file3 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/10-fold-result/F_test_two_result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree).to_csv(text_file3)

        accuracy = accuracy_score(sc_true, scoree)
        print("Accuracy: {:.6f}".format(accuracy))
        precision = precision_score(sc_true, scoree)
        print("Precision: {:.6f}".format(precision))
        recall = recall_score(sc_true, scoree)
        print("Recall: {:.6f}".format(recall))
        f1 = f1_score(sc_true, scoree)
        print("F1-score: {:.6f}".format(f1))
        #print(np.concatenate((data['m_num'][data['unsamples']],score),axis=1))
        one_score=[aucc,auprc,accuracy,precision,recall,f1]
        all_score.append(one_score)


        # 此处为未被选中样本结果
        # text_file31 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/unsample_10-fold/fold_{}.csv".format(fold)
        # data_unsample=np.array(pd.read_csv(text_file31).iloc[:,1:])
        # scoree1, _, _, _, _ = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, data_unsample)
        # scoree1 = scoree1.cpu()
        # scoree1 = scoree1.detach().numpy()
        # scoree1 = np.array(scoree1)
        # scoree1 = scoree1.ravel()
        # text_file4 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/unsample_10-fold/result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree1).to_csv(text_file4)
        # for i in range(len(scoree1)):
        #     if scoree1[i] >=optimal_threshold:
        #         scoree1[i]=1
        #     else:
        #         scoree1[i]=0
        # text_file5 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Fdataset/unsample_10-fold/result_two_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree1).to_csv(text_file5)

        #此处为未被选中样本结果
        # text_file31 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/unsample_10-fold/fold_{}.csv".format(fold)
        # data_unsample = np.array(pd.read_csv(text_file31).iloc[:, 1:])
        # scoree1, _, _, _, _ = model(mm_graph, dd_graph, md_graph, miRNA_th, disease_th, data_unsample)
        # scoree1 = scoree1.cpu()
        # scoree1 = scoree1.detach().numpy()
        # scoree1 = np.array(scoree1)
        # scoree1 = scoree1.ravel()
        # text_file4 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/unsample_10-fold/result_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree1).to_csv(text_file4)
        # for i in range(len(scoree1)):
        #     if scoree1[i] >= optimal_threshold:
        #         scoree1[i] = 1
        #     else:
        #         scoree1[i] = 0
        # text_file5 = "D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/Cdataset/unsample_10-fold/result_two_fold_{}.csv".format(fold)
        # pd.DataFrame(scoree1).to_csv(text_file5)

    cv_metric = np.mean(all_score, axis=0)
    print('################10-Fold Result################')
    print_met(cv_metric)
    return scoree