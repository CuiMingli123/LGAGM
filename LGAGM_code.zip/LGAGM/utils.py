import dgl
import math
import random
import numpy as np
import pandas as pd
import torch as th
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.model_selection import KFold
th.manual_seed(123)

def get_edge_index(matrix):
    edge_index = [[], []]
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            if matrix[i][j] != 0:
                edge_index[0].append(i)
                edge_index[1].append(j)
    return th.LongTensor(edge_index)


def make_adj(edges, size):
    edges_tensor = th.LongTensor(edges).t()
    values = th.ones(len(edges))
    adj = th.sparse.LongTensor(edges_tensor, values, size).to_dense().long()
    # adj_dense=adj
    # adj_dense.long()
    return adj


def predict_case(data, args):
    data['m_d_matrix'] = make_adj(data['m_d'], (args.miRNA_number, args.disease_number))
    m_d_matrix = data['m_d_matrix']
    one_index = []
    zero_index = []
    for i in range(m_d_matrix.shape[0]):
        for j in range(m_d_matrix.shape[1]):
            if m_d_matrix[i][j] >= 1:
                one_index.append([i, j])
            else:
                zero_index.append([i, j])
    random.seed(args.random_seed)

    random.shuffle(one_index)
    one_index = np.array(one_index)
    random.shuffle(zero_index)
    zero_index = np.array(zero_index)

    train = np.concatenate(
        (one_index, zero_index[:int(args.negative_rate * len(one_index))]))
    mm = data['mm_f'] * np.where(data['mm_f'] == 0, 0, 1) + get_gaussian(data['m_d_matrix']) * np.where(
        data['mm_f'] == 1, 0, 1)
    dd = data['dd_s'] * np.where(data['dd_s'] == 0, 0, 1) + get_gaussian(data['m_d_matrix'].t()) * np.where(
        data['dd_s'] == 1, 0, 1)
    data['mm'] = {'data_matrix': mm, 'edges': get_edge_index(mm)}
    data['dd'] = {'data_matrix': dd, 'edges': get_edge_index(dd)}
    data['train'] = train


def data_processing(data, args):
    md_matrix = make_adj(data['md'], (args.miRNA_number, args.disease_number))
    one_index = []
    zero_index = []
    for i in range(md_matrix.shape[0]):
        for j in range(md_matrix.shape[1]):
            if md_matrix[i][j] >= 1:
                one_index.append([i, j])
            else:
                zero_index.append([i, j])
    random.seed(args.random_seed)
    random.shuffle(one_index)
    random.shuffle(zero_index)
    unsamples=[]
    if args.negative_rate == -1:
        zero_index = zero_index
    else:
        unsamples = zero_index[int(args.negative_rate * len(one_index)):]
        zero_index = zero_index[:int(args.negative_rate * len(one_index))]
    index = np.array(one_index + zero_index, int)
    label = np.array([1] * len(one_index) + [0] * len(zero_index), dtype=int)
    samples = np.concatenate((index, np.expand_dims(label, axis=1)), axis=1)
    md = samples[samples[:, 2] == 1, :2]
    md_matrix = make_adj(md, (args.miRNA_number, args.disease_number))
    md_matrix = md_matrix.numpy()

    gm = get_gaussian(md_matrix)
    gd = get_gaussian(md_matrix.transpose())

    # 构建相似性共有四种方法：
    # （1）使用药物smiles相似性矩阵和疾病语义相似性矩阵
    # （2）使用药物高斯核相似性和疾病高斯核相似性矩阵
    # （3）使用两种药物相似性矩阵和两种高斯核相似性矩阵，加和取平均
    # （4）以药物smiles相似性和疾病语义相似性矩阵为主，采用核相似性作为数据补充

    # 第（4）种
    # ms = np.where(data['mf'] == 0, gm, data['mf'])
    # ds = np.where(data['dss'] == 0, gd, data['dss'])

    # 第（3）种
    # ms =(data['mf'] + gm)/2
    # ds =(data['dss'] + gd)/2

    # 第（2）种
    # ms = gm
    # ds = gs

    # 第（1）种
    ms = data['mf']
    ds = data['dss']


    data['ms'] = ms
    data['ds'] = ds

    # data['train_samples'] = samples

    #data['train_samples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/B_samples.csv").iloc[:, 1:])
    #data['train_samples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/F_samples.csv").iloc[:,1:])
    data['train_samples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/C_samples.csv").iloc[:, 1:])

    # data['train_samples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/sample.csv"))


    data['train_md'] = md

    # data['unsamples']=np.array(unsamples)

    #data['unsamples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/B_unsamples.csv").iloc[:, 1:])
    #data['unsamples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/F_unsamples.csv").iloc[:,1:])
    data['unsamples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/result/C_unsamples.csv").iloc[:, 1:])

    # data['unsamples'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/unsample.csv"))




def k_matrix(matrix, k=20):
    num = matrix.shape[0]
    knn_graph = np.zeros(matrix.shape)
    idx_sort = np.argsort(-(matrix - np.eye(num)), axis=1)
    for i in range(num):
        knn_graph[i, idx_sort[i, :k + 1]] = matrix[i, idx_sort[i, :k + 1]]
        knn_graph[idx_sort[i, :k + 1], i] = matrix[idx_sort[i, :k + 1], i]
    return knn_graph + np.eye(num)

def get_data(args):
    data = dict()


    # # F数据集
    # mf = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/drug.csv", header=None),dtype=float)
    # ds1 = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/disease.csv", header=None),dtype=float)

    # drug-cir数据集
    # mf = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/drug_str_sim.csv").iloc[:,1:],dtype=float)
    # ds1 = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/gene_seq_sim.csv").iloc[:,1:],dtype=float)


    # C数据集
    mf = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/drug_drug_baseline.csv", header=None),dtype=float)
    ds1 = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/disease_disease_baseline.csv", header=None),dtype=float)

    # B数据集
    # mf = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/drug_drug_baseline.csv", header=None),dtype=float)
    # ds1 = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/disease_disease_baseline.csv", header=None),dtype=float)

    dss=ds1
    data['miRNA_number'] = int(mf.shape[0])
    data['disease_number'] = int(dss.shape[0])
    data['mf'] = mf
    data['dss'] = dss

    # # F数据集
    # data['m_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/drug_name.csv", header=None),dtype=str)
    # data['d_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/disease_name.csv", header=None),dtype=str)

    # drug-cir数据集
    # data['m_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/drug_name.csv", header=None), dtype=str)
    # data['d_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/rna_name.csv", header=None), dtype=str)

    # C数据集
    data['m_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/drug_name.csv", header=None), dtype=str)
    data['d_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/disease_name.csv", header=None), dtype=str)

    # B数据集
    # data['m_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/Omics/drug_name.csv", header=None), dtype=str)
    # data['d_num'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/Omics/disease_name.csv", header=None), dtype=str)


    # # F数据集
    # data['md']=np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/Fdataset.csv"),dtype=int)
    # C数据集
    data['md'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/Cdataset.csv"), dtype=int)
    # B数据集
    #data['md'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/Associations/Bdataset.csv"), dtype=int)

    # drug-cir数据集
    # data['md'] = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/sample.csv").iloc[:,0:2], dtype=int)

    return data


def get_gaussian(adj):
    Gaussian = np.zeros((adj.shape[0], adj.shape[0]), dtype=np.float32)
    gamaa = 1
    sumnorm = 0
    for i in range(adj.shape[0]):
        norm = np.linalg.norm(adj[i]) ** 2
        sumnorm = sumnorm + norm
    gama = gamaa / (sumnorm / adj.shape[0])
    for i in range(adj.shape[0]):
        for j in range(adj.shape[0]):
            Gaussian[i, j] = math.exp(-gama * (np.linalg.norm(adj[i] - adj[j]) ** 2))

    return Gaussian


