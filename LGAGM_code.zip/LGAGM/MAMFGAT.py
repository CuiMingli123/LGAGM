import dgl.nn.pytorch
import torch as th
from torch import nn,einsum
from dgl import function as fn
from dgl.nn import pytorch as pt
import numpy as np
import pandas as pd
import math
device = th.device("cuda:0" if th.cuda.is_available() else "cpu")

import torch
import torch.nn as nn
import torch.nn.functional as F

th.manual_seed(123)

def get_gaussian(adj):
    Gaussian = np.zeros((adj.shape[0], adj.shape[0]), dtype=np.float32)
    gamaa = 1
    sumnorm = 0
    for i in range(adj.shape[0]):
        norm = np.linalg.norm(adj[i]) ** 2
        sumnorm = sumnorm + norm
    gama = gamaa / (sumnorm / adj.shape[0])
    for i in range(adj.shape[0]):
        for j in range(adj.shape[0]):
            Gaussian[i, j] = math.exp(-gama * (np.linalg.norm(adj[i] - adj[j]) ** 2))

    return Gaussian

class DSAE(nn.Module):
    def __init__(self,N_INP,N_HIDDEN):
        super(DSAE, self).__init__()
        # encoder
        self.encoder = nn.Sequential(
            nn.Linear(in_features=N_INP, out_features=N_HIDDEN),
            nn.Sigmoid(),
            nn.Linear(N_HIDDEN, int(N_HIDDEN / 2)),
            nn.Sigmoid(),
            nn.Linear(int(N_HIDDEN / 2), int(N_HIDDEN / 4)),
            nn.Sigmoid(),
            nn.Linear(int(N_HIDDEN / 4), int(N_HIDDEN / 8)),
            nn.Sigmoid()
        )
        # decoder
        self.decoder = nn.Sequential(
            nn.Linear(int(N_HIDDEN / 8), int(N_HIDDEN / 4)),
            nn.Sigmoid(),
            nn.Linear(int(N_HIDDEN / 4), int(N_HIDDEN / 2)),
            nn.Sigmoid(),
            nn.Linear(int(N_HIDDEN / 2), N_HIDDEN),
            nn.Sigmoid(),
            nn.Linear(N_HIDDEN, N_INP),
            nn.Sigmoid(),
        )

    def forward(self, x):
        x = x.view(x.size(0), -1)
        encode = self.encoder(x)
        decode = self.decoder(encode)
        return decode

class MLP(nn.Module):
    def __init__(self,input_size,out_size):
        super(MLP, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(input_size, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, out_size)
        )

    def forward(self, x):
        x = x.view(x.size(0), -1)  # 将输入数据展平为一维向量
        x = self.layers(x)          # 通过多层感知器进行前向传播
        return x


class GCN(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(GCN, self).__init__()
        self.dense = nn.Linear(input_dim, output_dim)

    def forward(self, adjacency_matrix):
        # 对输入矩阵进行图卷积操作
        x = self.dense(adjacency_matrix)
        x = F.relu(x)
        return x


class AttentionModule(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(AttentionModule, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size

        # 定义注意力权重的参数矩阵
        self.W = nn.Parameter(torch.Tensor(hidden_size, input_size * 3))
        self.b = nn.Parameter(torch.Tensor(hidden_size))

        # 初始化参数
        nn.init.xavier_uniform_(self.W)
        nn.init.zeros_(self.b)

    def forward(self, input1, input2, input3):
        # 将输入矩阵串联成一个大矩阵
        combined_input = torch.cat((input1, input2, input3), dim=1)

        # 计算注意力权重
        attention_weights = torch.matmul(self.W, combined_input.t()).t() + self.b
        attention_weights = F.softmax(attention_weights, dim=1)

        # 加权求和得到最终的节点表示矩阵
        output = attention_weights[:, 0].unsqueeze(1) * input1 + attention_weights[:, 1].unsqueeze(1) * input2 + attention_weights[:, 2].unsqueeze(1) * input3

        return output


class Autoencoder(nn.Module):
    def __init__(self, input_dim, hidden_dim=128, latent_dim=64):
        super(Autoencoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 64),  # 设置解码器输出维度为32
            nn.Sigmoid()  # 用于将输出限制在 [0, 1] 范围内，适用于输入为相似性矩阵的情况
        )

    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded




class GatedGraphNetworkWithDeepWalk(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GatedGraphNetworkWithDeepWalk, self).__init__()

        self.node_update = nn.Sequential(
            nn.Linear(input_dim * 3, 256),
            nn.ReLU(),
            nn.Linear(256, input_dim*3),
            nn.ReLU()
        )

        self.gate_function = nn.Sequential(
            nn.Linear(input_dim*3, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
            nn.Sigmoid()
        )

        self.output_function = nn.Sequential(
            nn.Linear(input_dim*3, 256),
            nn.ReLU(),
            nn.Linear(256, output_dim)
        )

    def forward(self, node_features, topology_features, deepwalk_features):
        combined_input = torch.cat([node_features, topology_features, deepwalk_features], dim=-1)

        updated_node_features = torch.relu(self.node_update(combined_input))

        combined_representation = torch.cat([node_features, topology_features, deepwalk_features], dim=-1)
        gate_values = torch.sigmoid(self.gate_function(combined_representation))
        combined_representation = gate_values * updated_node_features + (1 - gate_values) * combined_representation

        output = self.output_function(combined_representation)

        return output

class GatedGraphNetworkWithDeepWalk_Compare(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GatedGraphNetworkWithDeepWalk_Compare, self).__init__()

        self.node_update = nn.Sequential(
            nn.Linear(input_dim * 2, 256),
            nn.ReLU(),
            nn.Linear(256, input_dim*2),
            nn.ReLU()
        )

        self.gate_function = nn.Sequential(
            nn.Linear(input_dim*2, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
            nn.Sigmoid()
        )

        self.output_function = nn.Sequential(
            nn.Linear(input_dim*2, 256),
            nn.ReLU(),
            nn.Linear(256, output_dim)
        )

    def forward(self, node_features, topology_features):
        combined_input = torch.cat([node_features, topology_features], dim=-1)

        updated_node_features = torch.relu(self.node_update(combined_input))

        combined_representation = torch.cat([node_features, topology_features], dim=-1)
        gate_values = torch.sigmoid(self.gate_function(combined_representation))
        combined_representation = gate_values * updated_node_features + (1 - gate_values) * combined_representation

        output = self.output_function(combined_representation)

        return output

class GatedGraphNetworkWithDeepWalk_Compare1(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GatedGraphNetworkWithDeepWalk_Compare1, self).__init__()

        self.node_update = nn.Sequential(
            nn.Linear(input_dim , 256),
            nn.ReLU(),
            nn.Linear(256, input_dim),
            nn.ReLU()
        )

        #修改门控函数维度 初始：256，128
        self.gate_function = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
            nn.Sigmoid()
        )

        # self.gate_function = nn.Sequential(
        #     nn.Linear(input_dim, 64),
        #     nn.ReLU(),
        #     nn.Linear(64, 32),
        #     nn.ReLU(),
        #     nn.Linear(32, 1),
        #     nn.Sigmoid()
        # )

        self.output_function = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Linear(256, output_dim)
        )


    def forward(self, node_features):
        combined_input = node_features

        updated_node_features = torch.relu(self.node_update(combined_input))

        combined_representation = node_features
        gate_values = torch.sigmoid(self.gate_function(combined_representation))


        combined_representation = gate_values * updated_node_features + (1 - gate_values) * combined_representation

        output = self.output_function(combined_representation)

        return output


class MAMFGAT(nn.Module):
    def __init__(self, args):
        super(MAMFGAT, self).__init__()
        self.args = args
        self.lin_m=nn.Linear(args.miRNA_number,args.in_feats,bias=False)
        self.lin_d=nn.Linear(args.disease_number,args.in_feats,bias=False)

        # 3层gcn
        self.gcn_mm_1 = pt.GATConv(args.miRNA_number,64,num_heads=10,feat_drop=0.2)
        self.gcn_mm_2 = pt.GATConv(64, 64,num_heads=10,feat_drop=0.2)
        self.gcn_mm_3 = pt.GATConv(64,args.out_feats,num_heads=1,feat_drop=0.2)
        self.res_l_1 = pt.nn.Linear(args.miRNA_number,64)


        self.gcn_dd_1 = pt.GATConv(args.disease_number, 64,num_heads=10,feat_drop=0.2)
        self.gcn_dd_2 = pt.GATConv(64, 64,num_heads=10,feat_drop=0.2)
        self.gcn_dd_3 = pt.GATConv(64,args.out_feats,num_heads=1,feat_drop=0.2)
        self.res_l_2 = pt.nn.Linear(args.disease_number, 64)

        self.gcn_md_1 = pt.GATConv(args.in_feats,64,num_heads=10,feat_drop=0.2, allow_zero_in_degree=True)
        self.gcn_md_2 = pt.GATConv(64, 64,num_heads=10, feat_drop=0.2, allow_zero_in_degree=True)
        self.gcn_md_3 = pt.GATConv(64,args.out_feats,num_heads=1,feat_drop=0.2, allow_zero_in_degree=True)
        self.res_l_3 = pt.nn.Linear(args.in_feats,args.out_feats)


        # 4层gcn
        # self.gcn_mm_1 = pt.GATConv(args.miRNA_number,64,num_heads=10,feat_drop=0.2)
        # self.gcn_mm_2 = pt.GATConv(64, 64,num_heads=10,feat_drop=0.2)
        # self.gcn_mm_3 = pt.GATConv(64, 64, num_heads=10, feat_drop=0.2)
        # self.gcn_mm_4 = pt.GATConv(64,args.out_feats,num_heads=1,feat_drop=0.2)
        # self.res_l_1 = pt.nn.Linear(args.miRNA_number,64)
        #
        #
        # self.gcn_dd_1 = pt.GATConv(args.disease_number, 64,num_heads=10,feat_drop=0.2)
        # self.gcn_dd_2 = pt.GATConv(64, 64,num_heads=10,feat_drop=0.2)
        # self.gcn_dd_3 = pt.GATConv(64, 64, num_heads=10, feat_drop=0.2)
        # self.gcn_dd_4 = pt.GATConv(64,args.out_feats,num_heads=1,feat_drop=0.2)
        # self.res_l_2 = pt.nn.Linear(args.disease_number, 64)
        #
        # self.gcn_md_1 = pt.GATConv(args.in_feats,64,num_heads=10,feat_drop=0.2, allow_zero_in_degree=True)
        # self.gcn_md_2 = pt.GATConv(64, 64,num_heads=10, feat_drop=0.2, allow_zero_in_degree=True)
        # self.gcn_md_3 = pt.GATConv(64, 64, num_heads=10, feat_drop=0.2, allow_zero_in_degree=True)
        # self.gcn_md_4 = pt.GATConv(64,args.out_feats,num_heads=1,feat_drop=0.2, allow_zero_in_degree=True)
        # self.res_l_3 = pt.nn.Linear(args.in_feats,args.out_feats)


        # 2layer
        # self.gcn_mm_1 = pt.GATConv(args.miRNA_number, 64, num_heads=10, feat_drop=0.2)
        # self.gcn_mm_2 = pt.GATConv(64, args.out_feats, num_heads=1, feat_drop=0.2)

        # self.gcn_dd_1 = pt.GATConv(args.disease_number, 64, num_heads=10, feat_drop=0.2)
        # self.gcn_dd_2 = pt.GATConv(64, args.out_feats, num_heads=1, feat_drop=0.2)

        # self.gcn_md_1 = pt.GATConv(args.in_feats, 64, num_heads=10, feat_drop=0.2, allow_zero_in_degree=True)
        # self.gcn_md_2 = pt.GATConv(64, args.out_feats, num_heads=1, feat_drop=0.2, allow_zero_in_degree=True)


        # 1 layer
        # self.gcn_mm_1 = pt.GATConv(args.miRNA_number, 64, num_heads=10, feat_drop=0.2)
        # self.gcn_dd_1 = pt.GATConv(args.disease_number, 64, num_heads=10, feat_drop=0.2)
        # self.gcn_md_1 = pt.GATConv(args.in_feats, 64, num_heads=10, feat_drop=0.2, allow_zero_in_degree=True)

        self.elu = nn.ELU()
        self.mlp = nn.Sequential()
        self.dropout = nn.Dropout(args.dropout)
        #in_feat = 6 * args.out_feats  #直接拼接时使用的
        in_feat = 2 * args.out_feats    #门控机制和注意力都使用这个维度
        for idx, out_feat in enumerate(args.mlp):
            if idx==0:
                self.mlp.add_module(str(idx), nn.Linear(in_feat, out_feat))
                self.mlp.add_module('elu', nn.ELU())
                self.mlp.add_module('dropout', nn.Dropout(p=0.2))
                in_feat = out_feat
            else:
                self.mlp.add_module(str(idx), nn.Linear(in_feat, out_feat))
                self.mlp.add_module('sigmoid', nn.Sigmoid())
                self.mlp.add_module('dropout',nn.Dropout(p=0.2))
                in_feat = out_feat

        self.fuse_weight_1 = nn.Parameter(th.FloatTensor(1), requires_grad=True)
        self.fuse_weight_2 = nn.Parameter(th.FloatTensor(1), requires_grad=True)

        self.fuse_weight_1.data.fill_(0.5)
        self.fuse_weight_2.data.fill_(0.5)


        self.fuse_weight_m = nn.Parameter(th.FloatTensor(1), requires_grad=True)
        self.fuse_weight_d = nn.Parameter(th.FloatTensor(1), requires_grad=True)
        self.fuse_weight_md = nn.Parameter(th.FloatTensor(1), requires_grad=True)

        self.fuse_weight_m.data.fill_(0.5)
        self.fuse_weight_d.data.fill_(0.5)
        self.fuse_weight_md.data.fill_(0.5)

        # 定义注意力层
        self.integrate = GatedGraphNetworkWithDeepWalk(128, 64, 128)
        self.integrate_compare = GatedGraphNetworkWithDeepWalk_Compare(128, 64, 128)
        self.integrate_compare1 = GatedGraphNetworkWithDeepWalk_Compare1(128, 64, 128)
        self.autoencoder1 = Autoencoder(663 + 64)
        self.autoencoder2 = Autoencoder(409 + 64)
        self.attention_module = AttentionModule(128, 128)

        # 3层
        self.att1 = torch.nn.Parameter(torch.tensor([0.5,0.33,0.25]))
        self.att2 = torch.nn.Parameter(torch.tensor([0.5,0.33,0.25]))
        self.att3 = torch.nn.Parameter(torch.tensor([0.5,0.33,0.25]))#0.5 0.33 0.25

        # 2层
        # self.att1 = torch.nn.Parameter(torch.tensor([0.5, 0.5]))
        # self.att2 = torch.nn.Parameter(torch.tensor([0.5, 0.5]))
        # self.att3 = torch.nn.Parameter(torch.tensor([0.5, 0.5]))

        # 1层
        # self.att1 = torch.nn.Parameter(torch.tensor([0.5]))
        # self.att2 = torch.nn.Parameter(torch.tensor([0.5]))
        # self.att3 = torch.nn.Parameter(torch.tensor([0.5]))

        # 4层
        # self.att1 = torch.nn.Parameter(torch.tensor([0.5, 0.3,0.2,0.1]))
        # self.att2 = torch.nn.Parameter(torch.tensor([0.5, 0.3,0.2,0.1]))
        # self.att3 = torch.nn.Parameter(torch.tensor([0.5, 0.3,0.2,0.1]))

        # 目前模型中没有用到
        self.encoder=DSAE(663*2,64)
        self.encoder1=DSAE(409*2,64)
        self.mlp_new1=MLP(663*2,64)
        self.mlp_new2=MLP(409*2,64)
        self.mlp_all=MLP(593*2+313*2,128)


        self.trans_matrix1=torch.randn(663*2, 64)
        self.trans_matrix2=torch.randn(409*2, 64)

    def forward(self, mm_graph, dd_graph, md_graph, miRNA, disease, samples):
        mm_graph=mm_graph.to(device)
        dd_graph=dd_graph.to(device)
        md_graph=md_graph.to(device)
        miRNA=miRNA.to(device)
        disease=disease.to(device)

        # 3层gcn
        emb_mm_sim_1 = self.elu(self.gcn_mm_1(mm_graph, miRNA)).mean(dim=1)
        emb_mm_sim_1 = emb_mm_sim_1.view(emb_mm_sim_1.size(0), -1)
        emb_mm_sim_2 = self.elu(self.gcn_mm_2(mm_graph,emb_mm_sim_1)).mean(dim=1)
        emb_mm_sim_2 = emb_mm_sim_2.view(emb_mm_sim_2.size(0), -1)
        emb_mm_sim_3 = self.elu(self.gcn_mm_3(mm_graph, emb_mm_sim_2)).mean(dim=1)
        emb_mm_sim_3 = emb_mm_sim_3.view(emb_mm_sim_3.size(0), -1)
        emb_mm_sim_3= emb_mm_sim_1*self.att1[0]+emb_mm_sim_2*self.att1[1]+emb_mm_sim_3*self.att1[2]

        emb_dd_sim_1 = self.elu(self.gcn_dd_1(dd_graph, disease)).mean(dim=1)
        emb_dd_sim_1 = emb_dd_sim_1.view(emb_dd_sim_1.size(0), -1)
        emb_dd_sim_2 = self.elu(self.gcn_dd_2(dd_graph,emb_dd_sim_1)).mean(dim=1)
        emb_dd_sim_2 = emb_dd_sim_2.view(emb_dd_sim_2.size(0), -1)
        emb_dd_sim_3 = self.elu(self.gcn_dd_3(dd_graph, emb_dd_sim_2)).mean(dim=1)
        emb_dd_sim_3 = emb_dd_sim_3.view(emb_dd_sim_3.size(0), -1)
        emb_dd_sim_3 = emb_dd_sim_1 * self.att2[0] + emb_dd_sim_2 * self.att2[1] + emb_dd_sim_3 * self.att2[2]

        emb_ass_1 = self.elu(self.gcn_md_1(md_graph, th.cat((self.lin_m(miRNA),self.lin_d(disease)), dim=0))).mean(dim=1)
        emb_ass_1 = emb_ass_1.view(emb_ass_1.size(0), -1)
        emb_ass_2 = self.elu(self.gcn_md_2(md_graph,emb_ass_1 )).mean(dim=1)
        emb_ass_2 = emb_ass_2.view(emb_ass_2.size(0), -1)
        emb_ass_3 = self.elu(self.gcn_md_3(md_graph, emb_ass_2)).mean(dim=1)
        emb_ass_3 = emb_ass_3.view(emb_ass_3.size(0), -1)
        emb_ass_3 = emb_ass_1 * self.att3[0] + emb_ass_2 * self.att3[1] + emb_ass_3 * self.att3[2]



        #1层gcn
        # emb_mm_sim_1 = self.elu(self.gcn_mm_1(mm_graph, miRNA)).mean(dim=1)
        # emb_mm_sim_1 = emb_mm_sim_1.view(emb_mm_sim_1.size(0), -1)
        # emb_mm_sim_3 = emb_mm_sim_1
        #
        # emb_dd_sim_1 = self.elu(self.gcn_dd_1(dd_graph, disease)).mean(dim=1)
        # emb_dd_sim_1 = emb_dd_sim_1.view(emb_dd_sim_1.size(0), -1)
        # emb_dd_sim_3 = emb_dd_sim_1
        #
        # emb_ass_1 = self.elu(self.gcn_md_1(md_graph, th.cat((self.lin_m(miRNA), self.lin_d(disease)), dim=0))).mean(dim=1)
        # emb_ass_1 = emb_ass_1.view(emb_ass_1.size(0), -1)
        # emb_ass_3 = emb_ass_1

        # 2层
        # emb_mm_sim_1 = self.elu(self.gcn_mm_1(mm_graph, miRNA)).mean(dim=1)
        # emb_mm_sim_1 = emb_mm_sim_1.view(emb_mm_sim_1.size(0), -1)
        # emb_mm_sim_2 = self.elu(self.gcn_mm_2(mm_graph,emb_mm_sim_1)).mean(dim=1)
        # emb_mm_sim_2 = emb_mm_sim_2.view(emb_mm_sim_2.size(0), -1)
        # emb_mm_sim_3= emb_mm_sim_1*self.att1[0]+emb_mm_sim_2*self.att1[1]

        # emb_dd_sim_1 = self.elu(self.gcn_dd_1(dd_graph, disease)).mean(dim=1)
        # emb_dd_sim_1 = emb_dd_sim_1.view(emb_dd_sim_1.size(0), -1)
        # emb_dd_sim_2 = self.elu(self.gcn_dd_2(dd_graph,emb_dd_sim_1)).mean(dim=1)
        # emb_dd_sim_2 = emb_dd_sim_2.view(emb_dd_sim_2.size(0), -1)
        # emb_dd_sim_3 = emb_dd_sim_1*self.att2[0]+emb_dd_sim_2*self.att2[1]

        # emb_ass_1 = self.elu(self.gcn_md_1(md_graph, th.cat((self.lin_m(miRNA),self.lin_d(disease)), dim=0))).mean(dim=1)
        # emb_ass_1 = emb_ass_1.view(emb_ass_1.size(0), -1)
        # emb_ass_2 = self.elu(self.gcn_md_2(md_graph,emb_ass_1 )).mean(dim=1)
        # emb_ass_2 = emb_ass_2.view(emb_ass_2.size(0), -1)
        # emb_ass_3 = emb_ass_1*self.att3[0]+emb_ass_2*self.att3[1]


        # 4层gcn
        # emb_mm_sim_1 = self.elu(self.gcn_mm_1(mm_graph, miRNA)).mean(dim=1)
        # emb_mm_sim_1 = emb_mm_sim_1.view(emb_mm_sim_1.size(0), -1)
        # emb_mm_sim_2 = self.elu(self.gcn_mm_2(mm_graph,emb_mm_sim_1)).mean(dim=1)
        # emb_mm_sim_2 = emb_mm_sim_2.view(emb_mm_sim_2.size(0), -1)
        # emb_mm_sim_3 = self.elu(self.gcn_mm_3(mm_graph, emb_mm_sim_2)).mean(dim=1)
        # emb_mm_sim_3 = emb_mm_sim_3.view(emb_mm_sim_3.size(0), -1)
        # emb_mm_sim_4 = self.elu(self.gcn_mm_4(mm_graph, emb_mm_sim_3)).mean(dim=1)
        # emb_mm_sim_4 = emb_mm_sim_4.view(emb_mm_sim_4.size(0), -1)
        # emb_mm_sim_4= emb_mm_sim_1*self.att1[0]+emb_mm_sim_2*self.att1[1]+emb_mm_sim_3*self.att1[2]+emb_mm_sim_4*self.att1[3]
        #
        # emb_dd_sim_1 = self.elu(self.gcn_dd_1(dd_graph, disease)).mean(dim=1)
        # emb_dd_sim_1 = emb_dd_sim_1.view(emb_dd_sim_1.size(0), -1)
        # emb_dd_sim_2 = self.elu(self.gcn_dd_2(dd_graph,emb_dd_sim_1)).mean(dim=1)
        # emb_dd_sim_2 = emb_dd_sim_2.view(emb_dd_sim_2.size(0), -1)
        # emb_dd_sim_3 = self.elu(self.gcn_dd_3(dd_graph, emb_dd_sim_2)).mean(dim=1)
        # emb_dd_sim_3 = emb_dd_sim_3.view(emb_dd_sim_3.size(0), -1)
        # emb_dd_sim_4 = self.elu(self.gcn_dd_4(dd_graph, emb_dd_sim_3)).mean(dim=1)
        # emb_dd_sim_4 = emb_dd_sim_4.view(emb_dd_sim_4.size(0), -1)
        # emb_dd_sim_4 = emb_dd_sim_1 * self.att2[0] + emb_dd_sim_2 * self.att2[1] + emb_dd_sim_3 * self.att2[2]+emb_dd_sim_4*self.att2[3]
        #
        # emb_ass_1 = self.elu(self.gcn_md_1(md_graph, th.cat((self.lin_m(miRNA),self.lin_d(disease)), dim=0))).mean(dim=1)
        # emb_ass_1 = emb_ass_1.view(emb_ass_1.size(0), -1)
        # emb_ass_2 = self.elu(self.gcn_md_2(md_graph,emb_ass_1 )).mean(dim=1)
        # emb_ass_2 = emb_ass_2.view(emb_ass_2.size(0), -1)
        # emb_ass_3 = self.elu(self.gcn_md_3(md_graph, emb_ass_2)).mean(dim=1)
        # emb_ass_3 = emb_ass_3.view(emb_ass_3.size(0), -1)
        # emb_ass_4 = self.elu(self.gcn_md_4(md_graph, emb_ass_3)).mean(dim=1)
        # emb_ass_4 = emb_ass_4.view(emb_ass_4.size(0), -1)
        # emb_ass_4 = emb_ass_1 * self.att3[0] + emb_ass_2 * self.att3[1] + emb_ass_3 * self.att3[2]+emb_ass_4*self.att3[3]
        # emb_mm_ass = emb_ass_4[:self.args.miRNA_number, :]
        # emb_dd_ass = emb_ass_4[self.args.miRNA_number:, :]

        emb_mm_ass = emb_ass_3[:self.args.miRNA_number, :]
        emb_dd_ass = emb_ass_3[self.args.miRNA_number:, :]



        # 实验验证不使用相似性矩阵效果比较好
        emb_mm=emb_mm_ass
        emb_dd=emb_dd_ass
        emb = th.cat((emb_mm[samples[:, 0]], emb_dd[samples[:, 1]]), dim=1)

        # # B数据集
        # # 高阶信息
        # emb1 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/deepwalk_add_no_protein.csv").iloc[0:269, 1:]),dtype=th.float32)
        # emb2 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/deepwalk_add_no_protein.csv").iloc[269:269+598, 1:]), dtype=th.float32)
        # emb3 = th.cat((emb1[samples[:, 0]], emb2[samples[:, 1]]), dim=1)
        #
        # # 属性信息的提取与降维，通过PCA
        # features1 = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Bdataset/new1.csv").iloc[:, 1:])
        # emb4 = th.tensor(features1[0:269, ], dtype=th.float32)
        # emb5 = th.tensor(features1[269:269 + 598, ], dtype=th.float32)
        # emb6 = th.cat((emb4[samples[:, 0]], emb5[samples[:, 1]]), dim=1)

        # F数据集
        # 高阶信息
        # emb1 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/drug_high3.csv").iloc[:, 1:]), dtype=th.float32)
        # emb2 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/disease_high3.csv").iloc[:, 1:]), dtype=th.float32)
        # emb3 = th.cat((emb1[samples[:, 0]], emb2[samples[:, 1]]), dim=1)
        # # 属性信息的提取与降维，通过PCA
        # features1 = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Fdataset/guss.csv").iloc[:, 1:])
        # emb4 = th.tensor(features1[0:593, ], dtype=th.float32)
        # emb5 = th.tensor(features1[593:593 + 313, ], dtype=th.float32)
        # emb6 = th.cat((emb4[samples[:, 0]], emb5[samples[:, 1]]), dim=1)

        # drug-cir数据集
        # 高阶信息
        # emb1 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/drug_deepwalk.csv").iloc[:, 1:]),dtype=th.float32)
        # emb2 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/rna_deepwalk.csv").iloc[:, 1:]),dtype=th.float32)
        # emb3 = th.cat((emb1[samples[:, 0]], emb2[samples[:, 1]]), dim=1)
        #
        # emb4 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/drug_similarity.csv",header=None)),dtype=th.float32)
        # emb5 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/MAMFGAT-master-main/MAMFGAT-master/data/mydata/rna_similarity.csv",header=None)),dtype=th.float32)
        # emb6 = th.cat((emb4[samples[:, 0]], emb5[samples[:, 1]]), dim=1)


        # C数据集
        # 高阶信息
        emb1 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/drug_high.csv").iloc[:, 1:]),dtype=th.float32)
        emb2 = th.tensor(np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/disease_high.csv").iloc[:, 1:]),dtype=th.float32)
        emb3 = th.cat((emb1[samples[:, 0]], emb2[samples[:, 1]]), dim=1)
        # 属性信息的提取与降维，通过PCA
        # features1 = np.array(pd.read_csv("D:/pyproject/Bioinfomatics/REDDA-main/dataset/Cdataset/guss.csv").iloc[:, 1:])
        # emb4 = th.tensor(features1[0:663, ], dtype=th.float32)
        # emb5 = th.tensor(features1[663:663 + 409, ], dtype=th.float32)
        # emb6 = th.cat((emb4[samples[:, 0]], emb5[samples[:, 1]]), dim=1)

        # UMAP降维
        emb4 = th.tensor(np.array(pd.read_csv("D:/pyproject/Biowork4/TEMCL/data/C-dataset/Drug_UMAP_64D1.csv").iloc[:,1:]),dtype=th.float32)
        emb5 = th.tensor(np.array(pd.read_csv("D:/pyproject/Biowork4/TEMCL/data/C-dataset/Disease_UMAP_64D1.csv").iloc[:,1:]),dtype=th.float32)
        emb6 = th.cat((emb4[samples[:, 0]], emb5[samples[:, 1]]), dim=1)
        # ################10-Fold Result################
        # AUC ：0.8170  AUPR ：0.8165  Accuracy ：0.7536  precision ：0.7650  recall ：0.7353  f1_score ：0.7477
        # AUC ：0.8905  AUPR ：0.8977  Accuracy ：0.8195  precision ：0.8370  recall ：0.7938  f1_score ：0.8141



        # 下面是三种聚合信息的方式，可用作对比试验

        # 模型真正使用的门控机制
        embedding=self.integrate(emb,emb3,emb6)

        # 使用注意力机制，效果不好
        # embedding = self.attention_module(emb, emb3, emb6)

        # 拼接的效果不好
        # embedding = th.cat((emb,emb3,emb6), dim=1)

        # 用来进行消融实验
        # embedding=self.integrate_compare(emb3,emb6)

        result=self.mlp(embedding)
        return result,emb_mm_sim_3,emb_mm_ass,emb_dd_sim_3,emb_dd_ass


        # return result, emb_mm_sim_4, emb_mm_ass, emb_dd_sim_4, emb_dd_ass




